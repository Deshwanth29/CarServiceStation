#include<iostream>
#include<string>
#include<vector>
#include<vector>
using namespace std;



class Car
{
    public:
    string company_name;
    string model_number;
    string year_of_purchase;
    int no_of_Owners;
    string Registration_no;

    int odometer;
    string issues;
    string Date;
    double amount;
    string insurance_no;
    string insurance_expiry_date;
    int insurance_type;
    double insurance_premimumAmount;
    int chassis_no;
    string engine_no;
void setdata();



};

vector<Car> v={
    
    Car{"BMW","k2022","2022",2,"KA-11-M1929",1002,"Brake,gear",
    "22-20-2022",1000.89,"k1892","20-2-2029",3,1000,290,"En101"},
    {"BMW-X","k2021","2021",3,"KA-11-M9222",1002,"Brake,tyre",
    "22-20-2021",1000.89,"k182","5-2-2029",1,3000,290,"En107"}

    
    };
void Car::setdata()
{
    cout<<"Enter company name\n";
    getline(cin,company_name);
    cout<<"Enter model number\n";
    cin>>model_number;
    cout<<"Enter year of purchase\n";
    cin>>year_of_purchase;
    cout<<"Enter no of owners\n";
    cin>>no_of_Owners;
    cin.ignore();
    cout<<"Enter registration no\n";
    getline(cin,Registration_no);
    cout<<"Enter odometer\n";
    cin>>odometer;
    cin.ignore();
    cout<<"Enter issues\n";
    getline(cin,issues);
    cout<<"Enter Date in the format DD-MM-YYYY\n";
    cin>>Date;
    cout<<"Enter amount Paid\n";
    cin>>amount;
    cin.ignore();
    cout<<"Enter the Insurance Number\n";
    getline(cin,insurance_no);
    cout<<"Enter the Insurance Expiry Date\n";
    cin>>insurance_expiry_date;
    cout<<"Enter the Insurance type\n";
    cin>>insurance_type;
    cout<<"Enter the Insurance premimum amount\n";
    cin>>insurance_premimumAmount;
    cout<<"Enter the chassis number\n";
    cin>>chassis_no;
    cin.ignore();
    cout<<"Enter the Engine Number\n";
    getline(cin,engine_no);


    v.push_back(Car{company_name,model_number,year_of_purchase,no_of_Owners,Registration_no,odometer,
    issues,Date,amount,insurance_no,insurance_expiry_date,insurance_type,
    insurance_premimumAmount,chassis_no,engine_no});

  


}



