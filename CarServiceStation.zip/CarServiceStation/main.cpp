#include<iostream>
#include "mainclass.h"
using namespace std;
int main()
{
    a m;
    m.display();
    return 0;    
}