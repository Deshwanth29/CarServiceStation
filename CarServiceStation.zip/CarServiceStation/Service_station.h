#include<iostream>
#include<map>
#include "cars.h"
using namespace std;
class ServiceStation
{
    public:
    string Name;
    string Address;
    string Current_car_list;


    void add_car_service(string st);
    void service_car();
    void car_Bill();
    void remove_car(string s);
    void display_single_car(string reg);
    void display_all_cars();
    void drop_car_Service();
    void pick_car_from_Service();
    void Create_Car();
    void Update_Insurance();
    

};
map <string,string> mymap;
void ServiceStation::Create_Car()
{
    Car c;
    c.setdata();
    cout<<"Your car has been created\n";
}





void ServiceStation::add_car_service(string st)
{

    int flag=0;
    for(int i=0;i<v.size();i++)
    {
        if(v[i].Registration_no==st)
        {
            flag=1;
        
            string issues;
            int odometer;
            cout<<"Enter the odometer reading"<<endl;
            cin>>odometer;
            cin.ignore();
            v[i].odometer=odometer;
            cout<<"Enter the car issue"<<endl;
            getline(cin,issues);
           mymap.insert({st,issues});
           cout<<"Car is dropped for Service station\n"<<endl;
           break;

    }
    }
   
    
    if(flag==0)
    {
        cout<<"Your car Not Registered For Service"<<endl;
    }
}

void  ServiceStation::service_car()
{
    string reg;
    int flag=0;
    int Bill;
    cout<<"Enter the car registration number"<<endl;
    getline(cin, reg);
    cout<<"Your Bill is"<<endl;
    cin>>Bill;
    if (mymap.find(reg) != mymap.end()) {
        flag=1;
        cout<<"Car Services\n\n";
        for (auto i = mymap.begin(); i!= mymap.end(); i++) {

        cout <<i->second <<"\n"<<endl;

        remove_car(reg);

   }
        
    }
  

    if(flag==0)
    {
        cout<<"The car is not available for Pick up\n\n"<<endl;
    }

}

void ServiceStation::remove_car(string reg)
{
    int flag=0;
    for(int i=0;i<v.size();i++)
    {
        if(v[i].Registration_no==reg)
        {
            v.erase(v.begin()+i);
            cout<<"Car is removed from the list\n\n";
            flag=1;
            break;
        }
    }
    if(flag==0)
    {
        cout<<"No Car found\n";
}
}

void ServiceStation::display_single_car(string reg)
{
    int flag=0;
    for(int i=0;i<v.size();i++)
    {
        if(v[i].Registration_no==reg)
        {   
            flag=1;
            cout<<"Car Register Number: "<<v[i].Registration_no<<"\n\n";
            cout<<"Company Name: "<<v[i].company_name<<"\n\n";
            cout<<"Model Number: "<<v[i].model_number<<"\n\n";
            cout<<"Year of Purchase: "<<v[i].year_of_purchase<<"\n\n";
            cout<<"No of Owners: "<<v[i].no_of_Owners<<"\n\n";
            cout<<"Odometer: "<<v[i].odometer<<"\n\n";
            cout<<"Issues: "<<v[i].issues<<"\n\n";
            cout<<"Date: "<<v[i].Date<<"\n\n";
            cout<<"Amount: "<<v[i].amount<<"\n\n";
            cout<<"Insurance Number: "<<v[i].insurance_no<<"\n\n";
            cout<<"Insurance Expiry Date: "<<v[i].insurance_expiry_date<<"\n\n";
            cout<<"Insurance Type: "<<v[i].insurance_type<<"\n\n";
            cout<<"Insurance Primimum Amount: "<<v[i].insurance_premimumAmount<<"\n\n";
            cout<<"Chasis Number: "<<v[i].chassis_no<<"\n\n";
            cout<<"Engine Number: "<<v[i].engine_no<<"\n\n\n\n";
            break;



        }
    }
    if(flag==0)
    {
        cout<<"No Car found\n\n\n"<<endl;
    }
}

void ServiceStation::display_all_cars()

{
    cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;
    for(int i=0;i<v.size();i++)
    {
        display_single_car(v[i].Registration_no);
        cout<<"\n\n";
    }
   cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;

}


void ServiceStation::drop_car_Service()
{
 cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;
    string reg;
    int flag=0;
    cout<<"Enter the Car Register Number\n";
    getline(cin,reg);
    add_car_service(reg);

cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;

   
}


void ServiceStation::pick_car_from_Service()
{
        cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;

  service_car();
      cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;


}

void ServiceStation::Update_Insurance()
{
        cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;
    string reg;
    double ipa;
    string ins_no;
    int ins_t;
    string ins_date;
    int flag=0;
    cout<<"Enter the car registration number"<<endl;
    getline(cin, reg);
    cout<<"Enter the Insurance Primimum amount"<<endl;
    cin>>ipa;
    cin.ignore();
    cout<<"Enter the Insurance number"<<endl;
    getline(cin, ins_no);
    cout<<"Enter the Insurance Type"<<endl;
    cin>>ins_t;
    cin.ignore();
    cout<<"Enter the Insurance expiry date"<<endl;
    getline(cin, ins_date); 
    
    for(int i=0;i<v.size();i++)
    {
        if(v[i].Registration_no==reg)
        {
            string s=v[i].insurance_expiry_date;
            if((stoi(ins_date.substr(0,2))>=stoi(s.substr(0,2)) || stoi(ins_date.substr(3,2))>stoi(s.substr(3,2))) || stoi(ins_date.substr(6,4))>stoi(s.substr(6,4)))
            {
                flag=1;
                  v[i].insurance_expiry_date=ins_date;
                v[i].insurance_premimumAmount=ipa;
                v[i].insurance_no=ins_no;
                v[i].insurance_type=ins_t;
                v[i].insurance_expiry_date=ins_date;
                cout<<"Insurance Updation Sucessfull"<<endl;
            }

    
        }
}
        if(flag==0)
        {
            cout<<"Insurance Updation Unsuscessfull"<<endl;

        }

 cout<<"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n"<<endl;

}