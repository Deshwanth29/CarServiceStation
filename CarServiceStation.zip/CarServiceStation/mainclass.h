#include "Service_station.h"

class a
{
    public:
    void display(){
        string name;
        string addr;
        cout<<"Enter the name of the Car Service station"<<endl;
        getline(cin,name);
        cout<<"Enter the Address of the Car Service Station"<<endl;
        getline(cin,addr);
        cout<<"\n\n";
        cout<<"Welcome to "<<name<<"\n\n";
        int option;
    ServiceStation s;
        do{
    cout<<"Enter your option\n"<<endl;
    cout<<"1. Create Car\n"<<endl;
    cout<<"2. Print all Car Details\n"<<endl;
    cout<<"3. Update Insurance\n"<<endl;
    cout<<"4. Drop car to service\n"<<endl;
    cout<<"5. Pick up car from service\n"<<endl;
    cout<<"6. Exit\n"<<endl;

    
    cin>>option;
    cin.ignore();
    switch(option)
    {
        case 1:
        {
            s.Create_Car();
            break;

        }

        case 2:
        {
            s.display_all_cars();
            break;

        }

        case 3:
        {
            s.Update_Insurance();
            break;
        }
        case 4:
        {
            s.drop_car_Service();
            break;
        }
        case 5:
        {
            s.pick_car_from_Service();
                break;
        }
        case 6:
        {
            exit(1);
            break;
        }
}
    }while(option!=6);
    }
};
